﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InvisiblePlatforms : MonoBehaviour {

    public GameObject ThisPlatform;
	
	// Update is called once per frame
	void Update () {
		if(FindObjectOfType<SpriteBucket>().rightleg && FindObjectOfType<SpriteBucket>().leftleg)
        {
            ThisPlatform.SetActive(true);
        }
        else
        {
            ThisPlatform.SetActive(false);
        }
	}
}
