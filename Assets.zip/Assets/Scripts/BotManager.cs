﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BotManager : MonoBehaviour {

    public bool Level1 = false;
    public bool Level2 = false;
    public bool Level3 = false;
    public bool Level4 = false;

    public Sprite CurrentSprite;
    public Sprite CurrentJumpSprite;

    public bool RightLegRemoved = false;
    public bool LeftLegRemoved = false;
    public bool RightEyeRemoved = false;
    public bool LeftEyeRemoved = false;

    public int botPartChoice = 0;

    public int CurrentLevel = 0;

    public SpriteRenderer Player;

    //All Possible Sprites

    //Missing One part
    public Sprite RightEye;
    public Sprite RightEyeJump;
    public Sprite LeftEye;
    public Sprite LeftEyeJump;
    public Sprite RightLeg;
    public Sprite RightLegJump;
    public Sprite LeftLeg;
    public Sprite LeftLegJump;

    //Missing Two Parts
    public Sprite BothEyes;
    public Sprite BothEyesJump;
    public Sprite BothLegs;
    public Sprite RightEyeRightLeg;
    public Sprite RightEyeRightLegJump;
    public Sprite LeftEyeLeftLeg;
    public Sprite LeftEyeLeftLegJump;
    public Sprite RightEyeLeftLeg;
    public Sprite RightEyeLeftLegJump;
    public Sprite LeftEyeRightLeg;
    public Sprite LeftEyeRightLegJump;

    //Missing Three Parts
    public Sprite NoEyesRightLeg;
    public Sprite NoEyesRightLegJump;
    public Sprite NoEyesLeftLeg;
    public Sprite NoEyesLeftLegJump;
    public Sprite NoLegsRightEye;
    public Sprite NoLegsLeftEye;

    private void Start()
    {
        if(SceneManager.GetActiveScene().buildIndex == 1)
        {
            Level1 = true;
            Debug.Log("Currently on Level 1");
            CurrentLevel++;
        }

        else
        {
            Debug.Log("Retrieved Level");
            CurrentLevel = FindObjectOfType<SpriteBucket>().level;
        }

        if (!Level1)
        {
            CurrentLevel++;
        }

        if (CurrentLevel == 2)
        {
            Level2 = true;
        }

        if (CurrentLevel == 3)
        {
            Level3 = true;
        }

        if (CurrentLevel == 4)
        {
            Level4 = true;
        }

        Debug.Log(CurrentLevel + " Here is the Current Level");
        /*else
        {
            CurrentLevel++;
        }*/
        /*else
        {
            if(CurrentLevel == 2)
            {
                Level2 = true;
            }

            if (CurrentLevel == 3)
            {
                Level3 = true;
            }

            if (CurrentLevel == 4)
            {
                Level4 = true;
            }
        }*/
        if (!Level1)
        {
            RightLegRemoved = FindObjectOfType<SpriteBucket>().rightleg;
            LeftLegRemoved = FindObjectOfType<SpriteBucket>().leftleg;
            RightEyeRemoved = FindObjectOfType<SpriteBucket>().righteye;
            LeftEyeRemoved = FindObjectOfType<SpriteBucket>().lefteye;
        }
    
}

    // Update is called once per frame
    void Update () {
		
	}

    public void ChooseSprite()
    {
        botPartChoice = Random.Range(1, 5);
        Debug.Log(botPartChoice + "Current choice");
        if (botPartChoice == 1f)
        {
            if (RightLegRemoved)
            {
                ChooseSprite();
            }
            else
            {
                RightLegRemoved = true;
                //SpriteCalculator();
            }

        }

        else if (botPartChoice == 2)
        {
            if (LeftLegRemoved)
            {
                ChooseSprite();
            }
            else
            {
                LeftLegRemoved = true;
                //SpriteCalculator();
            }
        }

        else if (botPartChoice == 3)
        {
            if (RightEyeRemoved)
            {
                ChooseSprite();
            }
            else
            {
                RightEyeRemoved = true;
                //SpriteCalculator();
            }
        }
        else if (botPartChoice == 4)
        {
            if (LeftEyeRemoved)
            {
                ChooseSprite();
            }
            else
            {
                LeftEyeRemoved = true;
                //SpriteCalculator();
            }
        }
        else
        {
            Debug.Log("Not a valid value!");
        }

        //RightLegRemoved = true;

        

    }

    public void SpriteCalculator()
    {
        Debug.Log(CurrentLevel + "Here is the value of CurrentLevel");
        if ((CurrentLevel + 1) == 2)
        {
            Debug.Log("Calculating Part");
            //One Part Removed
            if (RightLegRemoved && !LeftLegRemoved && !RightEyeRemoved && !LeftEyeRemoved)
            {
                //The Right Leg is Gone!
                CurrentSprite = RightLeg;
                CurrentJumpSprite = RightLegJump;
                return;
            }

            else if (!RightLegRemoved && LeftLegRemoved && !RightEyeRemoved && !LeftEyeRemoved)
            {
                //The Left Leg is Gone
                CurrentSprite = LeftLeg;
                CurrentJumpSprite = LeftLegJump;
                return;
            }

            else if (!RightLegRemoved && !LeftLegRemoved && RightEyeRemoved && !LeftEyeRemoved)
            {
                //The Right Eye is Gone
                CurrentSprite = RightEye;
                CurrentJumpSprite = RightEyeJump;
                return;
            }

            else if (!RightLegRemoved && !LeftLegRemoved && !RightEyeRemoved && LeftEyeRemoved)
            {
                //The Left Eye is gone
                CurrentSprite = LeftEye;
                CurrentJumpSprite = LeftEyeJump;
                return;
            }

        }

        else if ((CurrentLevel + 1) == 3)
        {
            Debug.Log("We made it!");
            //Two Parts Removed
            if (RightLegRemoved && LeftLegRemoved && !RightEyeRemoved && !LeftEyeRemoved)
            {
                //Both Legs are gone!
                CurrentSprite = BothLegs;
                //No Jump sprite
                CurrentJumpSprite = BothLegs;
                return;
            }
            else if (!RightLegRemoved && LeftLegRemoved && RightEyeRemoved && !LeftEyeRemoved)
            {
                //The Left Leg and Right Eye Are gone!
                CurrentSprite = RightEyeLeftLeg;
                CurrentJumpSprite = RightEyeLeftLegJump;
                return;
            }
            else if (!RightLegRemoved && !LeftLegRemoved && RightEyeRemoved && LeftEyeRemoved)
            {
                //Both Eyes are gone!
                CurrentSprite = BothEyes;
                CurrentJumpSprite = BothEyesJump;
                return;
            }
            else if (RightLegRemoved && !LeftLegRemoved && RightEyeRemoved && !LeftEyeRemoved)
            {
                //The Right Leg and Right Eye are gone!
                CurrentSprite = RightEyeRightLeg;
                CurrentJumpSprite = RightEyeRightLegJump;
                return;
            }
            else if (!RightLegRemoved && LeftLegRemoved && !RightEyeRemoved && LeftEyeRemoved)
            {
                //The Left Leg and Left Eye are gone!
                CurrentSprite = LeftEyeLeftLeg;
                CurrentJumpSprite = LeftEyeLeftLegJump;
                return;
            }
            else if (RightLegRemoved && !LeftLegRemoved && !RightEyeRemoved && LeftEyeRemoved)
            {
                //The Right Leg and Left Eye are gone!
                CurrentSprite = LeftEyeRightLeg;
                CurrentJumpSprite = LeftEyeRightLegJump;
                return;
            }
        }



        else if ((CurrentLevel + 1) == 4)
        {
            //Three Parts are missing
            if (RightLegRemoved && LeftLegRemoved && RightEyeRemoved && !LeftEyeRemoved)
            {
                //Only the Left Eye remains!
                CurrentSprite = NoLegsLeftEye;
                //No JumpSprite
                CurrentJumpSprite = NoLegsLeftEye;
                return;
            }

            else if (RightLegRemoved && LeftLegRemoved && !RightEyeRemoved && LeftEyeRemoved)
            {
                //Only the Right Eye remains!
                CurrentSprite = NoLegsRightEye;
                //No Jump Sprite
                CurrentJumpSprite = NoLegsRightEye;
                return;
            }

            else if (RightLegRemoved && !LeftLegRemoved && RightEyeRemoved && LeftEyeRemoved)
            {
                //Only the Left Leg Remains
                CurrentSprite = NoEyesLeftLeg;
                CurrentJumpSprite = NoEyesLeftLegJump;
                return;
            }

            else if (!RightLegRemoved && LeftLegRemoved && RightEyeRemoved && LeftEyeRemoved)
            {
                //Only the Right Leg Remains
                CurrentSprite = NoEyesRightLeg;
                CurrentJumpSprite = NoEyesRightLegJump;
                return;
            }

        }

        else
        {
            Debug.Log("Problem with Level Variable!");
        }

    }
}
