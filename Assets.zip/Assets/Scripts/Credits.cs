﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class Credits : MonoBehaviour {

    public float delay = 3f;

    public GameObject screen;

    public void Redirect()
    {
        screen.SetActive(true);
        Invoke("nextScene", delay);
    }

    void nextScene()
    {
        SceneManager.LoadScene("Credits");
    }
}
